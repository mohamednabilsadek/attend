# حضوري على سيرفر Ubuntu محلي

الخادم هنا (`server.js`) يقدّم الصفحة وقاعدة البيانات من نفس العنوان. لا يحتاج أي مكتبات، فقط Node.js ≥ 16. البيانات في ملف واحد: `/opt/hudoori/data/hudoori-db.json`، مع نسخة يومية تلقائية في `data/backups/` (آخر 30 يومًا).

## 1) التثبيت
```bash
scp -r hudoori-selfhost user@SERVER:~/      # أو انسخ المجلد بأي طريقة
ssh user@SERVER
cd hudoori-selfhost
sudo bash install.sh
sudo nano /opt/hudoori/hudoori.env          # غيّر SETUP_CODE إلى رمز سري خاص بك
sudo systemctl enable --now hudoori
systemctl status hudoori                    # يجب أن يظهر active (running)
```
اختبار سريع: `curl -s localhost:8080/api -d '{"op":"status"}'`

> إذا كان إصدار Node قديمًا (< 16): `curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs`

## 2) HTTPS (ضروري لظهور إذن الكاميرا والموقع)
المتصفح يسمح بالكاميرا وGPS فقط على https (أو localhost). اختر أحد الحلول:

**أ) شبكة داخلية فقط (Caddy):**
```bash
sudo apt install -y caddy
sudo cp Caddyfile /etc/caddy/Caddyfile      # عدّل الاسم hudoori.lan، أو استعمل عنوان IP
sudo systemctl reload caddy
```
- اجعل الاسم يشير للسيرفر (سجل DNS في الراوتر، أو ملف hosts).
- Caddy يصدر شهادة خاصة به؛ على كل هاتف ثبّت شهادة الجذر مرة واحدة: `/var/lib/caddy/.local/share/caddy/pki/authorities/local/root.crt` (ثم فعّلها كـ CA موثوق). بدون ذلك سيحذّر المتصفح ولن يعمل الإذن بشكل سليم.

**ب) لديك دومين عام:** استعمل الخيار B في `Caddyfile` (افتح المنفذين 80 و443)، وتحصل على شهادة Let's Encrypt تلقائيًا بدون أي إعداد على الهواتف.

**ج) بدون فتح منافذ:** Cloudflare Tunnel أو Tailscale (Funnel) يعطيانك رابط https مباشرًا يشير إلى `localhost:8080`.

## 3) أول استخدام
افتح الرابط ← **مدير** ← **إنشاء قاعدة البيانات** ← رمز الإعداد = قيمة `SETUP_CODE`.

## 4) صيانة
- **سجلات:** `journalctl -u hudoori -f`
- **تحديث الصفحة/الخادم:** استبدل الملفات في `/opt/hudoori` ثم `sudo systemctl restart hudoori` (البيانات في `data/` لا تتأثر).
- **نسخ احتياطي:** انسخ `/opt/hudoori/data/` دوريًا إلى مكان آخر (الملف غير مشفّر، فاحمِه بصلاحيات السيرفر). وتبقى نسخة «التصدير المشفّر» من الإعدادات صالحة.
- **الانتقال من Google Apps Script:** من الإعدادات في النسخة القديمة اضغط «تصدير نسخة مشفّرة»، ثم على الموقع الجديد: مدير ← «استعادة نسخة احتياطية» (برمز الإعداد الجديد).
- **جدار الحماية:** افتح 443 (و80 إذا Let's Encrypt) فقط؛ المنفذ 8080 يبقى مقفلًا لأن الخادم يستمع على 127.0.0.1.
